package com.nt.service;

public class ArthmeticOperations {
	
	public  int sum(int x,int y) {
		return x+y;
	}

}
